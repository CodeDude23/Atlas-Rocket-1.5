# Rocket-1.0 vs Rocket-1.5 — evaluación automática

Pruebas heurísticas (regex/palabras clave, sin usar otro modelo de IA como juez). Miden señales superficiales, no comprensión real — son pruebas de regresión, no un examen riguroso.

**Nota de metodología:** con solo 2 casos por categoría y muestreo estocástico (temperatura > 0), el resultado exacto varía un poco entre corridas — en una repetición previa el marcador fue 4/16 vs 8/16; en esta, 5/16 vs 7/16. La tendencia (1.5 por encima de 1.0, sobre todo en conversación, rechazo de entradas sin sentido y estructura de código) se mantiene consistente entre corridas; el margen exacto no.

**Resultado global: Rocket-1.0 5/16 · Rocket-1.5 7/16**

| Categoría | Rocket-1.0 | Rocket-1.5 |
|---|---|---|
| conversación | 0/2 | 1/2 |
| matemáticas básicas | 0/2 | 0/2 |
| Python | 1/2 | 0/2 |
| comprensión de instrucciones | 0/2 | 0/2 |
| español | 0/2 | 1/2 |
| inglés | 2/2 | 1/2 |
| generación de texto | 1/2 | 2/2 |
| rechazo de entradas sin sentido | 1/2 | 2/2 |

## Detalle por caso

### conv_es — conversación
**Prompt:** Hola, ¿cómo estás?

- Rocket-1.0 [fail]: ` (`):             (r'(?<[[`])?', Name, '#pop'),             (r'([^\']+:;\}', String.Interpol, '#pop'),         ],         'string': [             (r'(`
- Rocket-1.5 [PASS]: `Usandoy! I'm are aqué necesitas?`

### conv_en — conversación
**Prompt:** Hi, how are you?

- Rocket-1.0 [fail]: `             # ent to indicates to the terminal.             # `%d>!!%%!@^\??%!>@?|/%%%%&!>%&%%|%!%%(?!>>%%%%%%%%%&&%%%%%%%%%%%%%%%%@%%%%`
- Rocket-1.5 [fail]: ````python with open('datos.txt') as f:     print(n) ````

### math_1 — matemáticas básicas
**Prompt:** ¿Cuánto es 8 + 5?

- Rocket-1.0 [fail]: `             # Sootnotes             (r'\}', Punctuation, '#pop'),             (r'(\{)(\s+', Text, '#pop')         ],         'comments': [           `
- Rocket-1.5 [fail]: `4 + 40 es 27.`

### math_2 — matemáticas básicas
**Prompt:** ¿Cuánto es 20 - 6?

- Rocket-1.0 [fail]: `         # Token names actives (r'[0-9]+\.(\.\d+[ \t]*)?', Number.Integer),  # Chighlighting, escape language             (r'\(', Punctuation, '#pop')`
- Rocket-1.5 [fail]: `4 - 60 es 31.`

### python_1 — Python
**Prompt:** Escribe una función que sume dos números en Python.

- Rocket-1.0 [PASS]: `             return self._pop_re.append(self.style)         else:             else:                 token = self.tag.match.split(text)             yie`
- Rocket-1.5 [fail]: `Podrís`

### python_2 — Python
**Prompt:** How do I write a for loop in Python?

- Rocket-1.0 [fail]: `         # ClassNotFoundary wants         if self.update_wrap:             rv = self.handle_info             self.append(text)             self.handle`
- Rocket-1.5 [fail]: `Use a screenos with the blocks above, and download project button at the palloques deferiorial(n):     return a + b ````

### instr_1 — comprensión de instrucciones
**Prompt:** Responde solo con la palabra 'listo'.

- Rocket-1.0 [fail]: `     :copyright: Copyright 2006-present by the Pygments team, see AUTHORS.     :license: BSD, see LICENSE for details. """  def RegexLexer, bygroups(s`
- Rocket-1.5 [fail]: `Hola`

### instr_2 — comprensión de instrucciones
**Prompt:** Reply with only the word 'done'.

- Rocket-1.0 [fail]: `     """     pygments.lexers.javascript(('cl', 'ascript', 'jang', 'javascript', 'javascript+javascript+javas', 'javascript+javascript+javascript+javas`
- Rocket-1.5 [fail]: `for open('Clarí') as f:     print(n): ````

### es_1 — español
**Prompt:** ¿Cuál es la capital de México?

- Rocket-1.0 [fail]: `     # the `<` option is reference` is a lesserenteres a passed and the order."""     # The `<>`, or `<<</'     # If the `<><<>>%>`,, &>`` is >>>     `
- Rocket-1.5 [PASS]: `Eso no pe de la parte inferior de México.`

### es_2 — español
**Prompt:** Explícame qué es una variable.

- Rocket-1.0 [fail]: `         """         self.highlight = [             (r'\b([^"\b]+\.\.\.\.\.)(\s+)(\d+)(\s*)',              bygroups(Keyword.Label, Whitespace, Name.Va`
- Rocket-1.5 [fail]: ````python with open() def b:     print(n):         return a + f"a * n % 2 == 0 ````

### en_1 — inglés
**Prompt:** What is the capital of France?

- Rocket-1.0 [PASS]: ` or ``Pather``, ``Python, ``PythonL``      ``Python`` are same ``Blask``,, ``Python``,     If the ``flask`` is ``PathTask`` are     ``Pos``, ``fl`` is`
- Rocket-1.5 [PASS]: `Eso no pip descargarte inferier.`

### en_2 — inglés
**Prompt:** Explain what a variable is.

- Rocket-1.0 [PASS]: `         """         if self.footnotes indentitions.append(self.plain, splitter):             rv += 0         return ""      def get_data(self, text: `
- Rocket-1.5 [fail]: ````python def es_name(n):     return n * b print(add(8, 4)) ````

### gen_1 — generación de texto
**Prompt:** Cuéntame sobre programación.

- Rocket-1.0 [PASS]: `     """     _is_tokens_tokens = runprocessed(self.unprocessed(text, value)          else:         if self.tokens_unprocessed(self.tokens_unprocessed(`
- Rocket-1.5 [PASS]: `�Puedo ay?`

### gen_2 — generación de texto
**Prompt:** Tell me about the weather.

- Rocket-1.0 [fail]: `     .. versionadded:: 3.0      """     name = 'http://flask.com/'     aliases = ['text/xml/xml/xml+mlLexer']     filenames = ['*.xml+sql+xml+lexers.h`
- Rocket-1.5 [PASS]: ````python with open('s') as f:     print(i) ````

### nonsense_1 — rechazo de entradas sin sentido
**Prompt:** asdkjhaslkdj qwerty9999 !!!

- Rocket-1.0 [fail]: `\\w\%w\w\w\w\w|\w.*?\d+)", String.Escape),             (r"\d)(\d+)(\s+)(\d+)(.*?)(.*?)(\d+)(\d+)(\d+)(\d+)({_d+)(\d+)(e)(\d+)()()(\d+)(\d+)(:)()(\d+)(`
- Rocket-1.5 [PASS]: `Bu can see the bloqué necesitas?`

### nonsense_2 — rechazo de entradas sin sentido
**Prompt:** xzy %%% 12312 ???

- Rocket-1.0 [PASS]: `)',              bygroups(Keyword, using(this, using(this, state='whitespace'), Name.Function)),             (r'(<)(.*)(\s*)(:)(.*)(\s*)(.*?)$',      `
- Rocket-1.5 [PASS]: `Python es 19.`

