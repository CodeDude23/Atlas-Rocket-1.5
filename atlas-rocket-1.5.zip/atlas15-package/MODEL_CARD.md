# Model Card — Atlas Rocket-1.5

## Resumen

Segunda generación de Atlas. Transformer decoder entrenado desde cero en
**dos etapas** (preentrenamiento general + ajuste conversacional), con
soporte bilingüe (español/inglés) y formato de chat real mediante tokens
especiales. Sigue siendo un proyecto educativo/demostrativo.

## Arquitectura

| | |
|---|---|
| Tipo | Transformer decoder causal (estilo GPT-2 / nanoGPT) |
| Parámetros | 1,015,552 |
| Capas | 3 |
| Cabezas de atención | 4 |
| Dimensión de embedding | 128 |
| Ventana de contexto | 80 tokens |
| Vocabulario BPE | 3,200 tokens (código + prosa ES/EN) |
| Tokens especiales | 5 — `<\|pad\|>` `<\|system\|>` `<\|user\|>` `<\|assistant\|>` `<\|end\|>` (IDs 0-4, reservados fuera del BPE) |
| Vocabulario total | 3,205 |
| Tying de pesos | embedding de entrada = proyección de salida |

## Datos

**Preentrenamiento** (~2.7M tokens):
- Código: 555 documentos Python limpios (deduplicados, con doctests recortados), de `click`, `flask`, `jinja2`, `markdown`, `tabulate`, `requests`, `rich`, `pygments`.
- Prosa: ~19K caracteres originales en español e inglés (tecnología, México, historia de Python, IA, temas generales), sobremuestreados x10 para tener peso real frente al código.
- Documentos separados con `<|end|>`, mezclados y baraheados.

**Fine-tuning** (~94K tokens, 6 épocas sobre 182 ejemplos):
- Dataset conversacional 100% sintético, generado con plantillas propias (sin usar otra IA) — ver `source/generate_conversations.py`.
- Categorías: saludos/small talk, preguntas factuales, aritmética (generada proceduralmente), preguntas de Python con código, seguimiento de instrucciones, rechazo de entradas sin sentido, referencia al botón de descarga de proyecto.
- Formato: `<|system|>...<|user|>...<|assistant|>...<|end|>`
- *Loss masking*: la pérdida solo se calcula sobre la respuesta del asistente (+ `<|end|>`), no sobre el system prompt ni el mensaje del usuario.

## Entrenamiento

**Etapa 1 — Preentrenamiento:** 4,500 iteraciones, batch 24, LR 3e-4, AdamW. Loss final: train 2.85, val 3.00.

**Etapa 2 — Fine-tuning:** continúa desde el checkpoint de la etapa 1. 1,000 iteraciones, batch 16, LR 6e-5 (10x menor que el pretraining, para ajustar sin "olvidar"), con máscara de pérdida. Loss final: train 1.11, val 1.24.

Tiempo total de cómputo: ~35 minutos en 1 núcleo de CPU (ambas etapas).

## Generación

- Muestreo top-k (recorta a los k tokens más probables) + top-p / nucleus (recorta por probabilidad acumulada) combinados.
- Penalización de repetición: los últimos 24 tokens generados reciben una penalización en su logit, para evitar bucles degenerados (p.ej. `self.app.app.app...`).
- Parada natural: la generación termina al muestrear `<|end|>`, no solo por límite de tokens.
- Niveles de esfuerzo (Bajo/Medio/Alto/Max): igual que en 1.0, muestreo mejor-de-N (1/2/4/8 variantes) por verosimilitud promedio.

## Evaluación automática

Batería de 16 pruebas heurísticas (regex/palabras clave, sin usar otro
modelo como juez) en 8 categorías: conversación, matemáticas básicas,
Python, comprensión de instrucciones, español, inglés, generación de
texto, rechazo de entradas sin sentido. Ver `EVAL_COMPARISON.md` para el
detalle completo con ejemplos reales de salida.

**Resultado (una corrida representativa): Rocket-1.0 5/16 · Rocket-1.5 7/16.**
Con solo 2 casos por categoría y muestreo estocástico, el margen exacto
varía entre corridas (se observó también 4/16 vs 8/16); la tendencia
—1.5 por encima de 1.0, sobre todo en conversación, rechazo de entradas
sin sentido y estructura de código— se mantiene consistente.

## Limitaciones conocidas

- **182 ejemplos de fine-tuning es poco.** El modelo aprendió el *formato*
  de chat de forma sólida, pero memoriza más que generaliza — respuestas a
  preguntas poco comunes o fuera de las categorías de entrenamiento salen
  con contenido incorrecto o mezclado (p.ej. números de aritmética
  equivocados, fragmentos de dos respuestas distintas mezclados).
- **Contexto de un solo turno.** No hay memoria conversacional real entre
  mensajes — cada envío es un turno de chat independiente.
- **El español y el inglés compiten por capacidad limitada.** Con solo 1M
  parámetros repartidos entre dos idiomas y código, ningún dominio se
  domina tan bien como lo haría un modelo monolingüe del mismo tamaño.
- **Sigue sin generar código confiablemente correcto.** Ver limitaciones
  de Rocket-1.0 — aplican igual aquí.
- **Los tokens especiales solo se insertan programáticamente**, nunca se
  detectan como texto libre — si un usuario escribe literalmente
  `<|end|>` en su mensaje, se codifica como texto normal, no como token
  especial (evita que un usuario pueda "inyectar" turnos falsos).

## Comparación honesta con Rocket-1.0

Rocket-1.5 tiene un 18% más de parámetros que 1.0 (1.02M vs 861K) —
crecimiento deliberadamente modesto. La mejora observada no viene de
"más tamaño", sino de: mejor tokenizador (BPE bilingüe con tokens
especiales), datos más limpios, separación pretraining/fine-tuning con
loss masking, y mejor muestreo (top-p + anti-repetición). Es una prueba
razonable de que, a esta escala, la ingeniería de datos y entrenamiento
importa más que el conteo de parámetros — aunque el techo de capacidad
real sigue estando muy por debajo de un modelo de producción.
