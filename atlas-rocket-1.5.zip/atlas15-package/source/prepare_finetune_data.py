import json
import random
import numpy as np
from tokenizers import Tokenizer

random.seed(11)

with open('bpe_export_v3.json') as f:
    bpe = json.load(f)
SPECIAL = bpe['special_tokens']
SYSTEM, USER, ASSISTANT, END = SPECIAL['system'], SPECIAL['user'], SPECIAL['assistant'], SPECIAL['end']
SHIFT = 5

tok = Tokenizer.from_file('bpe_tokenizer_v3.json')


def enc(text):
    return [i + SHIFT for i in tok.encode(text).ids]


examples = [json.loads(l) for l in open('conversations.jsonl', encoding='utf-8')]
random.shuffle(examples)
print('ejemplos de conversacion:', len(examples))

EPOCHS = 6  # repetir el dataset varias veces para que el fine-tuning tenga suficientes pasos
all_ids = []
all_mask = []  # 1 = se calcula perdida en este token (respuesta del asistente + <|end|>), 0 = no

for _ in range(EPOCHS):
    ex_shuffled = examples[:]
    random.shuffle(ex_shuffled)
    for ex in ex_shuffled:
        sys_ids = enc(ex['system'])
        user_ids = enc(ex['user'])
        asst_ids = enc(ex['assistant'])

        seq = [SYSTEM] + sys_ids + [USER] + user_ids + [ASSISTANT] + asst_ids + [END]
        mask = [0] * (1 + len(sys_ids) + 1 + len(user_ids) + 1) + [1] * (len(asst_ids) + 1)

        all_ids.extend(seq)
        all_mask.extend(mask)

all_ids = np.array(all_ids, dtype=np.uint16)
all_mask = np.array(all_mask, dtype=np.uint8)
print('tokens totales (finetune, {} epochs):'.format(EPOCHS), len(all_ids))
print('fraccion de tokens con perdida activa:', all_mask.mean())

n = len(all_ids)
split = int(n * 0.95)
all_ids[:split].tofile('data/train_finetune_ids.bin')
all_mask[:split].tofile('data/train_finetune_mask.bin')
all_ids[split:].tofile('data/val_finetune_ids.bin')
all_mask[split:].tofile('data/val_finetune_mask.bin')
print('train:', split, ' val:', n - split)
