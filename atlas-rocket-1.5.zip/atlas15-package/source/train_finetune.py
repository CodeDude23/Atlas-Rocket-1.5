import json
import os
import time
import numpy as np
import torch
from model import AtlasGPT

torch.manual_seed(2024)
torch.set_num_threads(1)

# --- Config (misma arquitectura que el pretraining) ---
block_size = 80
batch_size = 16
n_embd = 128
n_head = 4
n_layer = 3
dropout = 0.1
max_iters = 1000
eval_interval = 100
eval_iters = 20
lr = 6e-5  # LR bajo: ajuste fino, no reescribir lo aprendido en pretraining

with open('bpe_export_v3.json') as f:
    bpe = json.load(f)
vocab_size = bpe['vocab_size_total']

train_ids = np.fromfile('data/train_finetune_ids.bin', dtype=np.uint16)
train_mask = np.fromfile('data/train_finetune_mask.bin', dtype=np.uint8)
val_ids = np.fromfile('data/val_finetune_ids.bin', dtype=np.uint16)
val_mask = np.fromfile('data/val_finetune_mask.bin', dtype=np.uint8)


def get_batch(split):
    ids = train_ids if split == 'train' else val_ids
    mask = train_mask if split == 'train' else val_mask
    ix = np.random.randint(0, len(ids) - block_size - 1, size=(batch_size,))
    x = torch.stack([torch.from_numpy(ids[i:i + block_size].astype(np.int64)) for i in ix])
    y = torch.stack([torch.from_numpy(ids[i + 1:i + 1 + block_size].astype(np.int64)) for i in ix])
    m = torch.stack([torch.from_numpy(mask[i + 1:i + 1 + block_size].astype(np.int64)) for i in ix])
    return x, y, m


@torch.no_grad()
def estimate_loss(model):
    out = {}
    model.eval()
    for split in ['train', 'val']:
        losses = torch.zeros(eval_iters)
        for k in range(eval_iters):
            x, y, m = get_batch(split)
            _, loss = model(x, y, loss_mask=m)
            losses[k] = loss.item()
        out[split] = losses.mean().item()
    model.train()
    return out


model = AtlasGPT(vocab_size, block_size, n_embd, n_head, n_layer, dropout)

# --- cargar checkpoint del pretraining como punto de partida ---
start_iter = 0
CKPT = 'atlas15_finetune_ckpt.pt'
META = 'atlas15_finetune_meta.json'
if os.path.exists(CKPT) and os.path.exists(META):
    with open(META) as f:
        meta = json.load(f)
    model.load_state_dict(torch.load(CKPT, map_location='cpu'))
    start_iter = meta['iter']
    print(f"Reanudando fine-tuning desde iter {start_iter}")
else:
    model.load_state_dict(torch.load('atlas15_pretrain_ckpt.pt', map_location='cpu'))
    print("Fine-tuning iniciado desde el checkpoint de pretraining")

n_params = sum(p.numel() for p in model.parameters())
print(f"parametros del modelo: {n_params:,}  vocab_size: {vocab_size}")

optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)

t0 = time.time()
for it in range(start_iter, max_iters + 1):
    if it % eval_interval == 0 or it == max_iters:
        losses = estimate_loss(model)
        elapsed = time.time() - t0
        print(f"iter {it}: train loss {losses['train']:.4f}, val loss {losses['val']:.4f}, elapsed {elapsed:.1f}s", flush=True)
        torch.save(model.state_dict(), CKPT)
        with open(META, 'w') as f:
            json.dump({'iter': it}, f)

    xb, yb, mb = get_batch('train')
    logits, loss = model(xb, yb, loss_mask=mb)
    optimizer.zero_grad(set_to_none=True)
    loss.backward()
    optimizer.step()

print("Fine-tuning terminado.")
