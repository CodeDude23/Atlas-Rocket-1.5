import json
import random
import numpy as np
from tokenizers import Tokenizer

random.seed(7)

with open('bpe_export_v3.json') as f:
    bpe = json.load(f)
END = bpe['special_tokens']['end']
SHIFT = 5

tok = Tokenizer.from_file('bpe_tokenizer_v3.json')

with open('data/all_docs.json', 'r', encoding='utf-8') as f:
    docs = json.load(f)

random.shuffle(docs)

all_ids = []
for doc in docs:
    ids = tok.encode(doc).ids
    ids = [i + SHIFT for i in ids]
    all_ids.extend(ids)
    all_ids.append(END)

all_ids = np.array(all_ids, dtype=np.uint16)
print('tokens totales (pretraining):', len(all_ids))

n = len(all_ids)
train_ids = all_ids[: int(n * 0.97)]
val_ids = all_ids[int(n * 0.97):]

train_ids.tofile('data/train_pretrain.bin')
val_ids.tofile('data/val_pretrain.bin')
print('train:', len(train_ids), ' val:', len(val_ids))
