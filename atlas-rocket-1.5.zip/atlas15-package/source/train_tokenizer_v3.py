import json
from tokenizers import Tokenizer, models, pre_tokenizers, decoders, trainers

VOCAB_SIZE = 3200  # tamaño del vocab BPE puro (los 5 tokens especiales se añaden aparte, con IDs 0-4)

with open('data/all_docs.json', 'r', encoding='utf-8') as f:
    docs = json.load(f)

with open('data/combined_corpus.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(docs))

tokenizer = Tokenizer(models.BPE())
tokenizer.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
tokenizer.decoder = decoders.ByteLevel()

trainer = trainers.BpeTrainer(
    vocab_size=VOCAB_SIZE,
    min_frequency=2,
    special_tokens=[],
    show_progress=True,
    initial_alphabet=pre_tokenizers.ByteLevel.alphabet(),
)

tokenizer.train(['data/combined_corpus.txt'], trainer)
tokenizer.save('bpe_tokenizer_v3.json')

vocab = tokenizer.get_vocab()
print('vocab size real:', len(vocab))

tests = [
    "def calculate_total(items):\n    return sum(x.price for x in items)",
    "¿Cómo defino una función en Python?",
    "How do I define a function in Python?",
    "Hola, ¿cómo estás?",
]
for t in tests:
    enc = tokenizer.encode(t)
    dec = tokenizer.decode(enc.ids)
    print(f"{len(enc.ids):3d} tokens | roundtrip OK: {dec == t} | {t[:40]!r}")
