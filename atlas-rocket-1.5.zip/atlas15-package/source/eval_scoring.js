const GREETING_WORDS_ES = ['hola', 'bien', 'buenos', 'buenas', 'gracias', 'ayudarte', 'ayudar', 'necesitas'];
const GREETING_WORDS_EN = ['hi', 'hello', 'good', 'fine', 'help', 'thanks', 'today'];
const STOP_ES = ['de', 'la', 'que', 'el', 'en', 'y', 'es', 'un', 'una', 'los', 'las', 'con', 'para', 'por', 'te', 'se', 'su'];
const STOP_EN = ['the', 'of', 'and', 'is', 'a', 'in', 'to', 'for', 'you', 'it', 'that', 'this', 'with'];
const REFUSAL_WORDS = ['entend', 'reformul', 'clar', 'detalle', 'sure what', "doesn't look", "didn't understand", 'rephrase', 'explain'];

function normalize(s) {
  return (s || '').toLowerCase();
}

function hasLoop(text) {
  // detecta si alguna subcadena corta se repite 4+ veces seguidas (bucle degenerado)
  for (let len = 2; len <= 6; len++) {
    for (let i = 0; i + len * 4 <= text.length; i++) {
      const chunk = text.slice(i, i + len);
      if (chunk.trim().length === 0) continue;
      let reps = 1;
      let j = i + len;
      while (text.slice(j, j + len) === chunk) { reps++; j += len; }
      if (reps >= 4) return true;
    }
  }
  return false;
}

function countMatches(text, words) {
  const tokens = normalize(text).split(/[^a-záéíóúñ]+/i).filter(Boolean);
  const tokenSet = new Set(tokens);
  return words.filter((w) => tokenSet.has(w)).length;
}

function score(testCase, output) {
  const t = normalize(output);
  const nonEmpty = t.trim().length > 0;

  switch (testCase.check) {
    case 'greeting_es':
      return nonEmpty && !hasLoop(output) && countMatches(t, GREETING_WORDS_ES) >= 1;
    case 'greeting_en':
      return nonEmpty && !hasLoop(output) && countMatches(t, GREETING_WORDS_EN) >= 1;
    case 'contains':
      return t.includes(normalize(testCase.expect));
    case 'contains_all':
      return testCase.expect.every((w) => t.includes(normalize(w)));
    case 'contains_short':
      return t.includes(normalize(testCase.expect)) && output.length < 80;
    case 'lang_es': {
      const es = countMatches(t, STOP_ES), en = countMatches(t, STOP_EN);
      return nonEmpty && es > en;
    }
    case 'lang_en': {
      const es = countMatches(t, STOP_ES), en = countMatches(t, STOP_EN);
      return nonEmpty && en >= es;
    }
    case 'no_loops':
      return nonEmpty && !hasLoop(output);
    default:
      return false;
  }
}

module.exports = { score, hasLoop, countMatches };
