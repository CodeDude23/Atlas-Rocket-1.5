import json

SPECIAL_TOKENS = ['<|pad|>', '<|system|>', '<|user|>', '<|assistant|>', '<|end|>']
PAD, SYSTEM, USER, ASSISTANT, END = range(5)  # 0,1,2,3,4

with open('bpe_tokenizer_v3.json') as f:
    d = json.load(f)

vocab = d['model']['vocab']     # token_string -> id (0-indexed, BPE puro)
merges = d['model']['merges']   # lista de [a, b], SIN desplazar (son cadenas, no ids)

SHIFT = len(SPECIAL_TOKENS)  # 5

# vocab desplazado: token_string -> id+5
vocab_shifted = {tok: i + SHIFT for tok, i in vocab.items()}

# id -> token_string, con los especiales al frente
id_to_token = list(SPECIAL_TOKENS)
tmp = [None] * len(vocab)
for tok, i in vocab.items():
    tmp[i] = tok
id_to_token += tmp

out = {
    'special_tokens': {
        'pad': PAD, 'system': SYSTEM, 'user': USER, 'assistant': ASSISTANT, 'end': END,
    },
    'vocab': vocab_shifted,      # para encode() en JS (token_string -> id, ya desplazado)
    'id_to_token': id_to_token,  # para decode() en JS
    'merges': merges,            # las fusiones son sobre CADENAS, no cambian con el shift
    'vocab_size_total': len(id_to_token),
}

with open('bpe_export_v3.json', 'w', encoding='utf-8') as f:
    json.dump(out, f)

print('vocab BPE puro:', len(vocab))
print('vocab total (con especiales):', len(id_to_token))
print('SYSTEM id:', SYSTEM, ' USER id:', USER, ' ASSISTANT id:', ASSISTANT, ' END id:', END)
