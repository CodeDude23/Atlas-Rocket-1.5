// Escritor mínimo de archivos .zip, en JS puro, sin dependencias externas.
// Usa el método "stored" (sin compresión) — más simple y 100% confiable de
// implementar a mano; el trade-off es que el .zip no comprime, algo
// irrelevante aquí porque el contenido es texto/código pequeño.

function crc32(bytes) {
  let c;
  const table = crc32.table || (crc32.table = (() => {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      c = n;
      for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
      t[n] = c >>> 0;
    }
    return t;
  })());
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    crc = table[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function dosDateTime(date) {
  const time = ((date.getHours() & 0x1f) << 11) | ((date.getMinutes() & 0x3f) << 5) | ((date.getSeconds() >> 1) & 0x1f);
  const day = (((date.getFullYear() - 1980) & 0x7f) << 9) | (((date.getMonth() + 1) & 0xf) << 5) | (date.getDate() & 0x1f);
  return { time, day };
}

class ZipWriter {
  constructor() {
    this.files = []; // { name, bytes }
  }

  addTextFile(name, text) {
    const bytes = new TextEncoder().encode(text);
    this.files.push({ name, bytes });
  }

  // Devuelve un Blob con el .zip completo
  build() {
    const chunks = [];
    const centralRecords = [];
    let offset = 0;
    const { time, day } = dosDateTime(new Date());

    for (const file of this.files) {
      const nameBytes = new TextEncoder().encode(file.name);
      const crc = crc32(file.bytes);
      const size = file.bytes.length;

      const localHeader = new DataView(new ArrayBuffer(30));
      localHeader.setUint32(0, 0x04034b50, true);
      localHeader.setUint16(4, 20, true);
      localHeader.setUint16(6, 0, true);
      localHeader.setUint16(8, 0, true);
      localHeader.setUint16(10, time, true);
      localHeader.setUint16(12, day, true);
      localHeader.setUint32(14, crc, true);
      localHeader.setUint32(18, size, true);
      localHeader.setUint32(22, size, true);
      localHeader.setUint16(26, nameBytes.length, true);
      localHeader.setUint16(28, 0, true);

      chunks.push(new Uint8Array(localHeader.buffer));
      chunks.push(nameBytes);
      chunks.push(file.bytes);

      centralRecords.push({ nameBytes, crc, size, offset });
      offset += 30 + nameBytes.length + size;
    }

    const centralStart = offset;
    for (const rec of centralRecords) {
      const central = new DataView(new ArrayBuffer(46));
      central.setUint32(0, 0x02014b50, true);
      central.setUint16(4, 20, true);
      central.setUint16(6, 20, true);
      central.setUint16(8, 0, true);
      central.setUint16(10, 0, true);
      central.setUint16(12, time, true);
      central.setUint16(14, day, true);
      central.setUint32(16, rec.crc, true);
      central.setUint32(20, rec.size, true);
      central.setUint32(24, rec.size, true);
      central.setUint16(28, rec.nameBytes.length, true);
      central.setUint16(30, 0, true);
      central.setUint16(32, 0, true);
      central.setUint16(34, 0, true);
      central.setUint16(36, 0, true);
      central.setUint32(38, 0, true);
      central.setUint32(42, rec.offset, true);

      chunks.push(new Uint8Array(central.buffer));
      chunks.push(rec.nameBytes);
      offset += 46 + rec.nameBytes.length;
    }
    const centralSize = offset - centralStart;

    const end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true);
    end.setUint16(4, 0, true);
    end.setUint16(6, 0, true);
    end.setUint16(8, centralRecords.length, true);
    end.setUint16(10, centralRecords.length, true);
    end.setUint32(12, centralSize, true);
    end.setUint32(16, centralStart, true);
    end.setUint16(20, 0, true);
    chunks.push(new Uint8Array(end.buffer));

    return new Blob(chunks, { type: 'application/zip' });
  }

  download(filename) {
    const blob = this.build();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}

if (typeof module !== 'undefined') module.exports = { ZipWriter, crc32 };
