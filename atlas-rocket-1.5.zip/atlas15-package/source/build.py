with open('atlas_template_15.html', 'r', encoding='utf-8') as f:
    template = f.read()

with open('bpe_tokenizer.js', 'r', encoding='utf-8') as f:
    tokenizer_js = f.read()

with open('atlas_engine.js', 'r', encoding='utf-8') as f:
    engine_js = f.read()

with open('zip_writer.js', 'r', encoding='utf-8') as f:
    zip_js = f.read()

with open('atlas15_weights.json', 'r', encoding='utf-8') as f:
    weights_json = f.read()

out = template.replace('__ATLAS_TOKENIZER_JS__', tokenizer_js)
out = out.replace('__ATLAS_ENGINE_JS__', engine_js)
out = out.replace('__ZIP_WRITER_JS__', zip_js)
out = out.replace('__ATLAS_MANIFEST_JSON__', weights_json)

with open('atlas-rocket-1.5.html', 'w', encoding='utf-8') as f:
    f.write(out)

print('Tamaño final:', len(out) / 1024 / 1024, 'MB')
