const fs = require('fs');

const r10 = JSON.parse(fs.readFileSync('eval_results_1.0.json', 'utf8'));
const r15 = JSON.parse(fs.readFileSync('eval_results_1.5.json', 'utf8'));

const categories = [...new Set(r10.map((r) => r.category))];

function tally(results, cat) {
  const items = results.filter((r) => r.category === cat);
  const pass = items.filter((r) => r.pass).length;
  return `${pass}/${items.length}`;
}

let md = '# Rocket-1.0 vs Rocket-1.5 — evaluación automática\n\n';
md += 'Pruebas heurísticas (regex/palabras clave, sin usar otro modelo de IA como juez). ';
md += 'Miden señales superficiales, no comprensión real — son pruebas de regresión, no un examen riguroso.\n\n';

const total10 = r10.filter((r) => r.pass).length;
const total15 = r15.filter((r) => r.pass).length;
md += `**Resultado global: Rocket-1.0 ${total10}/${r10.length} · Rocket-1.5 ${total15}/${r15.length}**\n\n`;

md += '| Categoría | Rocket-1.0 | Rocket-1.5 |\n|---|---|---|\n';
for (const cat of categories) {
  md += `| ${cat} | ${tally(r10, cat)} | ${tally(r15, cat)} |\n`;
}

md += '\n## Detalle por caso\n\n';
for (let i = 0; i < r10.length; i++) {
  const a = r10[i], b = r15[i];
  md += `### ${a.id} — ${a.category}\n`;
  md += `**Prompt:** ${a.prompt}\n\n`;
  md += `- Rocket-1.0 [${a.pass ? 'PASS' : 'fail'}]: \`${a.output.replace(/\n/g, ' ').slice(0, 150)}\`\n`;
  md += `- Rocket-1.5 [${b.pass ? 'PASS' : 'fail'}]: \`${b.output.replace(/\n/g, ' ').slice(0, 150)}\`\n\n`;
}

fs.writeFileSync('EVAL_COMPARISON.md', md);
console.log(md.split('\n').slice(0, 20).join('\n'));
console.log('\n... (guardado completo en EVAL_COMPARISON.md)');
