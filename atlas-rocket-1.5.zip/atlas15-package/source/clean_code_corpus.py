import glob
import hashlib
import re

files = glob.glob('corpus_env/**/*.py', recursive=True)
print('archivos encontrados:', len(files))

seen_hashes = set()
kept_docs = []
stats = {'dup': 0, 'too_short': 0, 'too_many_doctest': 0, 'kept': 0}

DOCTEST_LINE = re.compile(r'^\s*>>>.*$', re.MULTILINE)


def clean_doctests(text):
    """Si un archivo tiene demasiadas líneas '>>>' (sesiones interactivas),
    las recorta a un máximo razonable para que no dominen el corpus."""
    lines = text.split('\n')
    out = []
    doctest_run = 0
    for line in lines:
        is_doctest = line.strip().startswith('>>>') or line.strip().startswith('...')
        if is_doctest:
            doctest_run += 1
            if doctest_run <= 2:
                out.append(line)
            # si hay más de 2 líneas seguidas de doctest, se omiten
        else:
            doctest_run = 0
            out.append(line)
    return '\n'.join(out)


for fp in files:
    try:
        with open(fp, 'r', encoding='utf-8') as f:
            text = f.read()
    except Exception:
        continue

    if len(text) < 200:
        stats['too_short'] += 1
        continue

    # filtrar a ASCII (consistente con el resto del proyecto)
    text = ''.join(c for c in text if ord(c) < 128)

    n_doctest_lines = len(DOCTEST_LINE.findall(text))
    ratio = n_doctest_lines / max(1, text.count('\n'))
    if ratio > 0.35:
        stats['too_many_doctest'] += 1
        continue

    text = clean_doctests(text)

    h = hashlib.sha256(text.encode('utf-8')).hexdigest()
    if h in seen_hashes:
        stats['dup'] += 1
        continue
    seen_hashes.add(h)

    kept_docs.append(text)
    stats['kept'] += 1

print(stats)

with open('data/code_docs.txt', 'w', encoding='utf-8') as f:
    f.write('\n<|end|>\n'.join(kept_docs))

total_chars = sum(len(d) for d in kept_docs)
print('documentos guardados:', len(kept_docs), ' caracteres totales:', total_chars)
