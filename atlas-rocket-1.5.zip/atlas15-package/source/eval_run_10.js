const fs = require('fs');
const path = require('path');

// Ajusta esta ruta a donde tengas los archivos de Rocket-1.0
// (atlas_weights_bpe.json, atlas_engine.js, bpe_tokenizer.js del paquete 1.0).
const ROCKET10_DIR = process.argv[2] || '../atlas-rocket-1.0-package/source';
const { BpeTokenizer } = require(path.join(ROCKET10_DIR, 'bpe_tokenizer.js'));
global.BpeTokenizer = BpeTokenizer;
const { AtlasModel } = require(path.join(ROCKET10_DIR, 'atlas_engine.js'));

const suite = require('./eval_suite.js');
const { score } = require('./eval_scoring.js');

const manifest = JSON.parse(fs.readFileSync(path.join(ROCKET10_DIR, 'atlas_weights_bpe.json'), 'utf8'));
const model = new AtlasModel(manifest);

const OPTS = { candidates: 2, maxNewTokens: 90, temperature: 0.7, topK: 20 };

(async () => {
  const results = [];
  for (const tc of suite) {
    // Rocket-1.0 no tiene formato de chat: solo puede CONTINUAR el texto tal cual.
    let out = '';
    for await (const ev of model.generateEffort(tc.prompt, OPTS)) {
      if (ev.type === 'token') out += ev.text;
      if (ev.type === 'done' || ev.type === 'result') out = ev.text;
    }
    const pass = score(tc, out);
    results.push({ id: tc.id, category: tc.category, prompt: tc.prompt, output: out, pass });
    console.log(`[${pass ? 'PASS' : 'fail'}] ${tc.id}`);
  }
  fs.writeFileSync('eval_results_1.0.json', JSON.stringify(results, null, 2));
  console.log('\nGuardado en eval_results_1.0.json');
})();
