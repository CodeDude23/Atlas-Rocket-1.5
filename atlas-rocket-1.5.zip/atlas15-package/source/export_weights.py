import json
import base64
import numpy as np
import torch

with open('bpe_export_v3.json') as f:
    bpe = json.load(f)

sd = torch.load('atlas15_finetune_ckpt.pt', map_location='cpu')

config = {
    'block_size': 80,
    'n_embd': 128,
    'n_head': 4,
    'n_layer': 3,
    'vocab_size': bpe['vocab_size_total'],
    'special_tokens': bpe['special_tokens'],
}

order = ['tok_emb.weight', 'pos_emb.weight']
for i in range(config['n_layer']):
    p = f'blocks.{i}.'
    order += [
        p + 'ln_1.weight', p + 'ln_1.bias',
        p + 'attn.c_attn.weight', p + 'attn.c_attn.bias',
        p + 'attn.c_proj.weight', p + 'attn.c_proj.bias',
        p + 'ln_2.weight', p + 'ln_2.bias',
        p + 'mlp.c_fc.weight', p + 'mlp.c_fc.bias',
        p + 'mlp.c_proj.weight', p + 'mlp.c_proj.bias',
    ]
order += ['ln_f.weight', 'ln_f.bias']

manifest = {
    'config': config,
    'bpe': {'vocab': bpe['vocab'], 'id_to_token': bpe['id_to_token'], 'merges': bpe['merges']},
    'tensors': [],
}
blob = bytearray()
offset = 0
for name in order:
    t = sd[name].detach().numpy().astype('<f4')
    flat = t.flatten()
    manifest['tensors'].append({
        'name': name,
        'shape': list(t.shape),
        'offset': offset,
        'length': int(flat.size),
    })
    blob += flat.tobytes()
    offset += flat.size

b64 = base64.b64encode(bytes(blob)).decode('ascii')
manifest['data_b64'] = b64
manifest['total_floats'] = offset

with open('atlas15_weights.json', 'w') as f:
    json.dump(manifest, f)

print('bytes crudos:', len(blob))
print('bytes base64:', len(b64))
print('total floats (parametros):', offset)
