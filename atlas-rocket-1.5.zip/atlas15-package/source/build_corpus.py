import glob
import json

# --- código (555 documentos ya limpios, separados por <|end|>) ---
with open('data/code_docs.txt', 'r', encoding='utf-8') as f:
    code_text = f.read()
code_docs = code_text.split('\n<|end|>\n')
code_docs = [d for d in code_docs if len(d.strip()) > 50]
print('documentos de código:', len(code_docs))

# --- prosa (ES/EN), sobremuestreada para que tenga peso real ---
prose_files = sorted(glob.glob('raw_wiki/*.txt'))
prose_docs = []
for fp in prose_files:
    with open(fp, 'r', encoding='utf-8') as f:
        text = f.read().strip()
    # dividir cada archivo en párrafos como documentos independientes
    paras = [p.strip() for p in text.split('\n\n') if len(p.strip()) > 80]
    prose_docs.extend(paras)
print('parrafos de prosa (antes de sobremuestrear):', len(prose_docs))

UPSAMPLE = 10
prose_docs_up = prose_docs * UPSAMPLE
print('parrafos de prosa (tras sobremuestrear x{}):'.format(UPSAMPLE), len(prose_docs_up))

all_docs = code_docs + prose_docs_up
print('total documentos:', len(all_docs))

total_chars = sum(len(d) for d in all_docs)
print('total caracteres:', total_chars)

with open('data/all_docs.json', 'w', encoding='utf-8') as f:
    json.dump(all_docs, f)
