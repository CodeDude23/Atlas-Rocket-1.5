import json
import os
import time
import numpy as np
import torch
from model import AtlasGPT

torch.manual_seed(1337)
torch.set_num_threads(1)

# --- Config ---
block_size = 80
batch_size = 24
n_embd = 128
n_head = 4
n_layer = 3
dropout = 0.1
max_iters = 4500
eval_interval = 250
eval_iters = 25
lr = 3e-4

with open('bpe_export_v3.json') as f:
    bpe = json.load(f)
vocab_size = bpe['vocab_size_total']

train_data = np.fromfile('data/train_pretrain.bin', dtype=np.uint16)
val_data = np.fromfile('data/val_pretrain.bin', dtype=np.uint16)


def get_batch(split):
    data = train_data if split == 'train' else val_data
    ix = np.random.randint(0, len(data) - block_size - 1, size=(batch_size,))
    x = torch.stack([torch.from_numpy(data[i:i + block_size].astype(np.int64)) for i in ix])
    y = torch.stack([torch.from_numpy(data[i + 1:i + 1 + block_size].astype(np.int64)) for i in ix])
    return x, y


@torch.no_grad()
def estimate_loss(model):
    out = {}
    model.eval()
    for split in ['train', 'val']:
        losses = torch.zeros(eval_iters)
        for k in range(eval_iters):
            x, y = get_batch(split)
            _, loss = model(x, y)
            losses[k] = loss.item()
        out[split] = losses.mean().item()
    model.train()
    return out


model = AtlasGPT(vocab_size, block_size, n_embd, n_head, n_layer, dropout)

start_iter = 0
CKPT = 'atlas15_pretrain_ckpt.pt'
META = 'atlas15_pretrain_meta.json'
if os.path.exists(CKPT) and os.path.exists(META):
    with open(META) as f:
        meta = json.load(f)
    model.load_state_dict(torch.load(CKPT, map_location='cpu'))
    start_iter = meta['iter']
    print(f"Reanudando pretraining desde iter {start_iter}")

n_params = sum(p.numel() for p in model.parameters())
print(f"parametros del modelo: {n_params:,}  vocab_size: {vocab_size}")

optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)

t0 = time.time()
for it in range(start_iter, max_iters + 1):
    if it % eval_interval == 0 or it == max_iters:
        losses = estimate_loss(model)
        elapsed = time.time() - t0
        print(f"iter {it}: train loss {losses['train']:.4f}, val loss {losses['val']:.4f}, elapsed {elapsed:.1f}s", flush=True)
        torch.save(model.state_dict(), CKPT)
        with open(META, 'w') as f:
            json.dump({'iter': it}, f)

    xb, yb = get_batch('train')
    logits, loss = model(xb, yb)
    optimizer.zero_grad(set_to_none=True)
    loss.backward()
    optimizer.step()

print("Pretraining terminado.")
