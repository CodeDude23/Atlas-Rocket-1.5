const fs = require('fs');

const { BpeTokenizer } = require('./bpe_tokenizer.js');
global.BpeTokenizer = BpeTokenizer;
const { AtlasModel } = require('./atlas_engine.js');

const suite = require('./eval_suite.js');
const { score } = require('./eval_scoring.js');

const manifest = JSON.parse(fs.readFileSync('atlas15_weights.json', 'utf8'));
const model = new AtlasModel(manifest);

const SYSTEM_PROMPT = "Eres Atlas, un asistente de programación pequeño y honesto, construido desde cero. Ayudas con Python y respondes en el idioma del usuario.";
const OPTS = { candidates: 2, maxNewTokens: 100, temperature: 0.7, topK: 20, topP: 0.9 };

(async () => {
  const results = [];
  for (const tc of suite) {
    const promptIds = model.buildChatPrompt(SYSTEM_PROMPT, tc.prompt);
    let out = '';
    for await (const ev of model.generateEffort(promptIds, OPTS)) {
      if (ev.type === 'token') out += ev.text;
      if (ev.type === 'done' || ev.type === 'result') out = ev.text;
    }
    const pass = score(tc, out);
    results.push({ id: tc.id, category: tc.category, prompt: tc.prompt, output: out, pass });
    console.log(`[${pass ? 'PASS' : 'fail'}] ${tc.id}`);
  }
  fs.writeFileSync('eval_results_1.5.json', JSON.stringify(results, null, 2));
  console.log('\nGuardado en eval_results_1.5.json');
})();
