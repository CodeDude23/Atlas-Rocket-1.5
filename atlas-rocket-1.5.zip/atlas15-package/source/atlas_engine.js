// Atlas Engine v1.5 — mini-Transformer (GPT-style) de inferencia, escrito a mano.
// Novedades sobre 1.0: tokens especiales (system/user/assistant/end) para modo
// chat real, muestreo top_p (nucleus) además de top_k, penalización de
// repetición para evitar bucles ("self.app.app.app..."), y parada natural
// al generar <|end|> en vez de solo por límite de tokens.

class AtlasModel {
  constructor(manifest) {
    this.cfg = manifest.config;
    this.tokenizer = new BpeTokenizer(manifest.bpe);
    this.special = this.cfg.special_tokens; // {pad,system,user,assistant,end}

    const raw = atob(manifest.data_b64);
    const buf = new ArrayBuffer(raw.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i < raw.length; i++) view[i] = raw.charCodeAt(i);
    const allFloats = new Float32Array(buf);

    this.tensors = {};
    for (const t of manifest.tensors) {
      this.tensors[t.name] = {
        data: allFloats.subarray(t.offset, t.offset + t.length),
        shape: t.shape,
      };
    }

    this.C = this.cfg.n_embd;
    this.nHead = this.cfg.n_head;
    this.hs = this.C / this.cfg.n_head;
    this.nLayer = this.cfg.n_layer;
    this.blockSize = this.cfg.block_size;
    this.vocabSize = this.cfg.vocab_size;
  }

  encode(text) {
    return this.tokenizer.encode(text);
  }

  decode(ids) {
    return this.tokenizer.decode(ids);
  }

  buildChatPrompt(systemText, userText) {
    const s = this.special;
    return [s.system, ...this.encode(systemText), s.user, ...this.encode(userText), s.assistant];
  }

  _linearVec(x, Wt, Bt, inF, outF) {
    const W = Wt.data, B = Bt ? Bt.data : null;
    const y = new Float32Array(outF);
    for (let o = 0; o < outF; o++) {
      let s = B ? B[o] : 0;
      const base = o * inF;
      for (let i = 0; i < inF; i++) s += x[i] * W[base + i];
      y[o] = s;
    }
    return y;
  }

  _layernormVec(x, Wt, Bt, C) {
    const W = Wt.data, B = Bt.data;
    let mean = 0;
    for (let i = 0; i < C; i++) mean += x[i];
    mean /= C;
    let vr = 0;
    for (let i = 0; i < C; i++) { const d = x[i] - mean; vr += d * d; }
    vr /= C;
    const inv = 1 / Math.sqrt(vr + 1e-5);
    const y = new Float32Array(C);
    for (let i = 0; i < C; i++) y[i] = (x[i] - mean) * inv * W[i] + B[i];
    return y;
  }

  _gelu(x) {
    const y = new Float32Array(x.length);
    const k = Math.sqrt(2 / Math.PI);
    for (let i = 0; i < x.length; i++) {
      const v = x[i];
      y[i] = 0.5 * v * (1 + Math.tanh(k * (v + 0.044715 * v * v * v)));
    }
    return y;
  }

  _newCache() {
    const cache = [];
    for (let l = 0; l < this.nLayer; l++) {
      const heads = [];
      for (let h = 0; h < this.nHead; h++) heads.push({ K: [], V: [] });
      cache.push(heads);
    }
    return cache;
  }

  _forwardStep(tokId, pos, cache) {
    const C = this.C, hs = this.hs, nHead = this.nHead;
    const tokEmb = this.tensors['tok_emb.weight'];
    const posEmb = this.tensors['pos_emb.weight'];

    let x = new Float32Array(C);
    for (let i = 0; i < C; i++) {
      x[i] = tokEmb.data[tokId * C + i] + posEmb.data[pos * C + i];
    }

    for (let l = 0; l < this.nLayer; l++) {
      const p = `blocks.${l}.`;
      const xNorm = this._layernormVec(x, this.tensors[p + 'ln_1.weight'], this.tensors[p + 'ln_1.bias'], C);
      const qkv = this._linearVec(xNorm, this.tensors[p + 'attn.c_attn.weight'], this.tensors[p + 'attn.c_attn.bias'], C, 3 * C);

      const attnOut = new Float32Array(C);
      for (let h = 0; h < nHead; h++) {
        const qh = qkv.subarray(h * hs, (h + 1) * hs);
        const kh = qkv.subarray(C + h * hs, C + (h + 1) * hs);
        const vh = qkv.subarray(2 * C + h * hs, 2 * C + (h + 1) * hs);

        cache[l][h].K.push(Float32Array.from(kh));
        cache[l][h].V.push(Float32Array.from(vh));

        const T = cache[l][h].K.length;
        const scores = new Float32Array(T);
        const scale = 1 / Math.sqrt(hs);
        let maxS = -Infinity;
        for (let t = 0; t < T; t++) {
          let s = 0;
          const Kt = cache[l][h].K[t];
          for (let d = 0; d < hs; d++) s += qh[d] * Kt[d];
          s *= scale;
          scores[t] = s;
          if (s > maxS) maxS = s;
        }
        let sumExp = 0;
        for (let t = 0; t < T; t++) { scores[t] = Math.exp(scores[t] - maxS); sumExp += scores[t]; }
        for (let t = 0; t < T; t++) scores[t] /= sumExp;

        for (let d = 0; d < hs; d++) {
          let acc = 0;
          for (let t = 0; t < T; t++) acc += scores[t] * cache[l][h].V[t][d];
          attnOut[h * hs + d] = acc;
        }
      }

      const proj = this._linearVec(attnOut, this.tensors[p + 'attn.c_proj.weight'], this.tensors[p + 'attn.c_proj.bias'], C, C);
      for (let i = 0; i < C; i++) x[i] += proj[i];

      const xNorm2 = this._layernormVec(x, this.tensors[p + 'ln_2.weight'], this.tensors[p + 'ln_2.bias'], C);
      const fc = this._linearVec(xNorm2, this.tensors[p + 'mlp.c_fc.weight'], this.tensors[p + 'mlp.c_fc.bias'], C, 4 * C);
      const act = this._gelu(fc);
      const mlpOut = this._linearVec(act, this.tensors[p + 'mlp.c_proj.weight'], this.tensors[p + 'mlp.c_proj.bias'], 4 * C, C);
      for (let i = 0; i < C; i++) x[i] += mlpOut[i];
    }

    const xf = this._layernormVec(x, this.tensors['ln_f.weight'], this.tensors['ln_f.bias'], C);
    const logits = new Float32Array(this.vocabSize);
    for (let v = 0; v < this.vocabSize; v++) {
      let s = 0;
      const base = v * C;
      for (let i = 0; i < C; i++) s += xf[i] * tokEmb.data[base + i];
      logits[v] = s;
    }
    return logits;
  }

  _sampleScored(logits, temperature, topK, topP, recentIds) {
    const n = logits.length;
    const REPEAT_PENALTY = 4.0;
    const recentSet = recentIds instanceof Set ? recentIds : new Set(recentIds || []);

    const scaled = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      let v = logits[i] / temperature;
      if (recentSet.has(i)) v -= REPEAT_PENALTY;
      scaled[i] = v;
    }

    let maxAll = -Infinity;
    for (let i = 0; i < n; i++) if (scaled[i] > maxAll) maxAll = scaled[i];
    let sumAll = 0;
    for (let i = 0; i < n; i++) sumAll += Math.exp(scaled[i] - maxAll);
    const logZ = Math.log(sumAll) + maxAll;

    let idxs = Array.from({ length: n }, (_, i) => i);
    idxs.sort((a, b) => scaled[b] - scaled[a]);

    if (topK && topK < idxs.length) idxs = idxs.slice(0, topK);

    if (topP && topP < 1.0) {
      let maxS0 = scaled[idxs[0]];
      let sumExp0 = 0;
      const probs0 = idxs.map((i) => { const e = Math.exp(scaled[i] - maxS0); sumExp0 += e; return e; });
      let cum = 0, cutoff = idxs.length;
      for (let k = 0; k < probs0.length; k++) {
        cum += probs0[k] / sumExp0;
        if (cum >= topP) { cutoff = k + 1; break; }
      }
      idxs = idxs.slice(0, cutoff);
    }

    let maxS = -Infinity;
    for (const i of idxs) if (scaled[i] > maxS) maxS = scaled[i];
    let sumExp = 0;
    const probs = [];
    for (const i of idxs) { const e = Math.exp(scaled[i] - maxS); probs.push(e); sumExp += e; }
    let r = Math.random() * sumExp;
    let chosen = idxs[idxs.length - 1];
    for (let k = 0; k < idxs.length; k++) {
      r -= probs[k];
      if (r <= 0) { chosen = idxs[k]; break; }
    }
    return { id: chosen, logProb: scaled[chosen] - logZ };
  }

  _runPassGen(promptIds, maxNewTokens, temperature, topK, topP) {
    const self = this;
    const END = this.special.end;
    return (function* () {
      let history = promptIds.slice(-self.blockSize);
      let cache = self._newCache();
      let logits = null;
      for (let i = 0; i < history.length; i++) logits = self._forwardStep(history[i], i, cache);
      let pos = history.length;

      let text = '';
      let sumLogProb = 0;
      let count = 0;
      let stoppedAtEnd = false;
      const recentWindow = [];
      const RECENT_MAX = 24;

      for (let n = 0; n < maxNewTokens; n++) {
        const { id, logProb } = self._sampleScored(logits, temperature, topK, topP, recentWindow);

        if (id === END) { stoppedAtEnd = true; break; }

        history.push(id);
        sumLogProb += logProb;
        count += 1;
        const piece = self.tokenizer.decode([id]);
        text += piece;
        yield piece;

        recentWindow.push(id);
        if (recentWindow.length > RECENT_MAX) recentWindow.shift();

        if (pos >= self.blockSize) {
          const keep = history.slice(-Math.floor(self.blockSize / 2));
          cache = self._newCache();
          for (let i = 0; i < keep.length; i++) logits = self._forwardStep(keep[i], i, cache);
          pos = keep.length;
        } else {
          logits = self._forwardStep(id, pos, cache);
          pos += 1;
        }
      }
      return { text, avgLogProb: count ? sumLogProb / count : -Infinity, stoppedAtEnd };
    })();
  }

  async *generateEffort(promptIds, opts) {
    const { candidates, maxNewTokens, temperature, topK, topP } = opts;

    if (candidates <= 1) {
      const gen = this._runPassGen(promptIds, maxNewTokens, temperature, topK, topP);
      let step = gen.next();
      let i = 0;
      while (!step.done) {
        yield { type: 'token', text: step.value };
        i++;
        if (i % 6 === 0) await new Promise((r) => setTimeout(r, 0));
        step = gen.next();
      }
      yield { type: 'done', text: step.value.text };
      return;
    }

    let best = null;
    for (let c = 0; c < candidates; c++) {
      yield { type: 'progress', current: c + 1, total: candidates };
      await new Promise((r) => setTimeout(r, 0));
      const gen = this._runPassGen(promptIds, maxNewTokens, temperature, topK, topP);
      let step = gen.next();
      let i = 0;
      while (!step.done) {
        i++;
        if (i % 10 === 0) await new Promise((r) => setTimeout(r, 0));
        step = gen.next();
      }
      const result = step.value;
      if (!best || result.avgLogProb > best.avgLogProb) best = result;
    }
    yield { type: 'result', text: best.text };
  }
}

if (typeof module !== 'undefined') module.exports = { AtlasModel };
