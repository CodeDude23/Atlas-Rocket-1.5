# Atlas Rocket-1.5

Segunda generación de Atlas: mismo espíritu de "modelo real, entrenado desde
cero, sin usar ninguna IA existente", pero ahora con **chat real** (no solo
continuación de código como 1.0), bilingüe (español/inglés), y con un botón
para descargar el código que genera como proyecto en `.zip`.

## Uso

Abre `atlas-rocket-1.5.html` en cualquier navegador moderno. Funciona 100%
offline — no hay servidor, backend, ni conexión a internet involucrada.

Ahora puedes simplemente conversar:

```
Hola, ¿cómo estás?
Escribe una función que sume dos números
How do I read a file in Python?
```

Cualquier bloque de código que Atlas genere se acumula automáticamente en
la barra superior ("proyecto: N archivos") — haz clic en **📦 Descargar
proyecto (.zip)** en cualquier momento para bajar todo el código generado
en la conversación, junto con la transcripción completa.

## Qué cambió respecto a Rocket-1.0

| | Rocket-1.0 | Rocket-1.5 |
|---|---|---|
| Formato | solo continuación de texto | chat real (system/user/assistant) |
| Idiomas | inglés (código) | español + inglés |
| Tokenizador | BPE, 2,000 tokens | BPE, 3,205 tokens (código+prosa ES/EN) + 5 tokens especiales de chat |
| Entrenamiento | una sola etapa | dos etapas: pretraining + fine-tuning con *loss masking* |
| Parámetros | 861,312 | 1,015,552 |
| Muestreo | top-k | top-k + top-p (nucleus) + penalización de repetición |
| Parada de generación | por límite de tokens | natural, en `<|end|>` |
| Descarga de código | no | sí, botón de proyecto en `.zip` |
| Evaluación | ninguna | batería de 16 pruebas automáticas (ver `EVAL_COMPARISON.md`) |

**Rocket-1.0 no se tocó** — sigue disponible tal cual, intacto, para comparar.

## Qué es (y qué no es) — sé honesto contigo

Rocket-1.5 entiende bien: saludos, aritmética simple, la *forma* de un
bloque de código Python, y reconoce cuándo una entrada es basura sin
sentido. Se equivoca con frecuencia en: el contenido exacto de las
respuestas (números, nombres de variables), instrucciones poco comunes, y
cualquier cosa fuera de los patrones que vio en sus ~180 ejemplos de
entrenamiento conversacional. Ver `MODEL_CARD.md` y `EVAL_COMPARISON.md`
para el detalle completo, con ejemplos reales de aciertos y fallos.

Sigue siendo, deliberadamente, un modelo de ~1 millón de parámetros — no
crecimos el tamaño "a lo loco"; el objetivo de esta versión era mejorar el
*comportamiento* (chat, dos idiomas, evaluación) sin abandonar la filosofía
de "pequeño y rápido".

## Contenido de esta carpeta

```
atlas-rocket-1.5.html      ← la app, todo en un solo archivo
README.md                  ← este archivo
MODEL_CARD.md               ← ficha técnica completa
EVAL_COMPARISON.md          ← comparación automática 1.0 vs 1.5, con ejemplos
source/                     ← todo el código fuente (dos etapas de entrenamiento,
                               generador de datos conversacionales, tokenizador,
                               motor JS, escritor de zip, arnés de evaluación)
```

## Reentrenar / mejorar el modelo

```bash
pip install torch tokenizers numpy
```

Pipeline completo, en orden:

```bash
python3 clean_code_corpus.py        # limpia el corpus de código (dedup, quita exceso de >>>)
python3 build_corpus.py             # combina código + prosa ES/EN (con sobremuestreo de prosa)
python3 train_tokenizer_v3.py       # entrena el tokenizador BPE
python3 export_bpe_v3.py            # reserva los 5 tokens especiales de chat
python3 prepare_pretrain_data.py    # codifica el corpus general
python3 generate_conversations.py   # genera el dataset conversacional sintético
python3 prepare_finetune_data.py    # codifica las conversaciones + máscara de pérdida
python3 train_pretrain.py           # etapa 1: lenguaje general (reanudable)
python3 train_finetune.py           # etapa 2: chat (reanudable, parte del checkpoint de pretrain)
python3 export_weights.py           # exporta los pesos finales
python3 build.py                    # ensambla el .html final
node eval_run_15.js && node build_eval_report.js   # evaluación automática
```

Ideas honestas para una v1.6/v2.0, en orden de impacto probable:
1. Más ejemplos conversacionales (182 es poco; 1,000+ ayudaría mucho más que agrandar el modelo)
2. Multi-turno real (ahora mismo cada conversación es de un solo turno de contexto)
3. Mejor pretraining (más datos de prosa — hoy son solo ~19K caracteres antes de sobremuestrear)
